import React from 'react';

const Label = ({ children }) => {
  return <div className="counter__label">{children}</div>;
};

export default Label;
